﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XamarinChallengeApril.Services;

namespace XamarinChallengeApril.ViewModels
{
    class ItemViewModel
    {
        //private IronHttpClientService mHttpService;


        //private async void getData()
        //{
        //    var items = await mHttpService.getItems();
        //}
    }
}
