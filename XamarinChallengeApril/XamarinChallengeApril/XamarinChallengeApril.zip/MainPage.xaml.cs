﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using XamarinChallengeApril.Services;

namespace XamarinChallengeApril
{
    public partial class MainPage : ContentPage
    {
        private IronHttpClientService mHttpService;


        
        public MainPage()
        {
            InitializeComponent();
            mHttpService = new IronHttpClientService();

            getData();
        }
        private async void getData()
        {
            var test = await mHttpService.getItems();
        }
    }
}
