﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using XamarinChallengeApril.Models;

namespace XamarinChallengeApril.Services
{
    class IronHttpClientService
    {
        private HttpClient mHttpClient = new HttpClient();
        private int mPage = 1;
        public IronHttpClientService()
        {
        }
        public async Task<IList<Item>> getItems()
        {
            IList<Item> items = null;

            try
            {
                var tempResult = await mHttpClient.GetStringAsync("https://randomuser.me/api/?page="+mPage+"&results=10&seed=abc");

                Debug.WriteLine("Test");
                //var result = JsonConvert.DeserializeObject<Result>(json);
                //users = result.Results.ToList();
            }
            catch (Exception e)
            {
                items = new List<Item>();
                items.Add(new Item
                {
                    Name = e.Message
                });
                throw new Exception(e.Message);
            }
            items = new List<Item>();
            items.Add(new Item
            {
                Name = "test"
            });
            return items;
        }
    }
}
